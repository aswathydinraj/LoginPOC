package stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	WebDriver driver;

//Launch the driver and load the URL	
	@Given("^User is already on the login page$")
	public void user_already_on_login_page() throws InterruptedException {
		Thread.sleep(5000);
		System.setProperty("webdriver.chrome.driver", "Driver\\windows\\chromedriver.exe");
		Thread.sleep(5000);
		DesiredCapabilities capability = DesiredCapabilities.chrome();
		capability.setCapability("chrome.binary", "Driver\\windows\\chromedriver.exe");
		driver = new ChromeDriver(capability);
		// driver= new ChromeDriver();
		driver.get("https://accounts.google.com/signin");
	}

// Verify the title of the Login page
	@When("^title of the login page is Google Accounts$")
	public void title_of_the_login_page_is_Google_Accounts() {
		String title = driver.getTitle();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//Assert.assertEquals("Sign in – Google accounts", title);
		Assert.assertTrue(title.contains("Sign in"),"Sign in – Google accounts" );
	}

//User clicks on Next button
	@And("^user click on next button$")
	public void user_click_on_next_button() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/content/span")).click();
	}

//User clicks on next button
	@Then("^user click on next button to proceed$")
	public void user_click_on_next_button_to_proceed() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
	}

//User enters valid email address
	@Then("^user enters correct email (.*)$")
	public void user_enters_correct_username(String username) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.id("identifierId")).sendKeys(username);

	}

//User enters correct password
	@When("^the user enters correct password (.*)$")
	public void the_user_enters_correct_password(String password) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.name("password")).sendKeys(password);

	}

//Verify user lands on welcome page
	@And("^user has successfully logged in to the application$")
	public void user_has_successfully_logged_into_the_application() throws InterruptedException {
		Thread.sleep(5000);
		String title = driver.getTitle();
		System.out.print("success title" +title);
		Assert.assertEquals("Google Account", title);

	}

//User clicks on logout button
	@Then("^user clicks on logout button$")
	public void user_clicks_on_logout_button() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"gb\"]/div[2]/div[3]/div/div/div/a/span")).click();
		driver.findElement(By.linkText("Sign out")).click();
	}

//User enters incorrect email
	@Then("^user enters incorrect email (.*)$")
	public void the_user_enters_incorrect_email(String username) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.id("identifierId")).sendKeys(username);
	}

//Verification of error message for invalid username
	@And("^Error message is displayed$")
	public void error_message_is_displayed() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		String errorMessage = driver.findElement(By.xpath(
				"//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/content/section/div/content/div[1]/div/div[2]/div[2]/div"))
				.getText();
		Assert.assertEquals("Couldn't find your Google Account", errorMessage);
		
	}

//user enters invalid password
	@When("^the user enters incorrect password (.*)$")
	public void the_user_enters_incorrect_password(String password) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.name("password")).sendKeys(password);
	}

//Verification of error message for invalid password
	@And("^Error should be displayed$")
	public void error_should_be_displayed() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(5000);
		String errorMessage = driver.findElement(By.xpath(
				"//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/content/section/div/content/div[1]/div[2]/div[2]/content"))
				.getText();
		Assert.assertEquals("Wrong password. Try again or click Forgot password to reset it.", errorMessage);
		
	}

//Verification of successfully logout
	@Then("^user should be logged out successfully$")
	public void user_should_be_logged_out_successfully() throws InterruptedException {
		Thread.sleep(5000);
		String title = driver.getTitle();
		Assert.assertEquals("Sign in – Google accounts", title);
		
	}
	
//Close the browser
	@And("^application should be closed$")
	public void application_should_be_closed()
	{
		driver.quit();
	}

}
