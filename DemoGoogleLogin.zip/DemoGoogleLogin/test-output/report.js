$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("login.feature");
formatter.feature({
  "line": 1,
  "name": "Google Login",
  "description": "",
  "id": "google-login",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "User should be able to login with examples",
  "description": "",
  "id": "google-login;user-should-be-able-to-login-with-examples",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 2,
      "name": "@googlelogin"
    }
  ]
});
formatter.step({
  "line": 4,
  "name": "User is already on the login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "title of the login page is Google Accounts",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters correct email \u003cusername\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user click on next button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "the user enters correct password \u003cpassword\u003e",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user click on next button to proceed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user has successfully logged in to the application",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "application should be closed",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "google-login;user-should-be-able-to-login-with-examples;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 14,
      "id": "google-login;user-should-be-able-to-login-with-examples;;1"
    },
    {
      "cells": [
        "rmgtestdemo1@gmail.com",
        "Rmg@12345"
      ],
      "line": 15,
      "id": "google-login;user-should-be-able-to-login-with-examples;;2"
    },
    {
      "cells": [
        "rmgtestdemo2@gmail.com",
        "Rmg@12345"
      ],
      "line": 16,
      "id": "google-login;user-should-be-able-to-login-with-examples;;3"
    },
    {
      "cells": [
        "rmgtestdemo3@gmail.com",
        "Rmg@12345"
      ],
      "line": 17,
      "id": "google-login;user-should-be-able-to-login-with-examples;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "User should be able to login with examples",
  "description": "",
  "id": "google-login;user-should-be-able-to-login-with-examples;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 2,
      "name": "@googlelogin"
    }
  ]
});
formatter.step({
  "line": 4,
  "name": "User is already on the login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "title of the login page is Google Accounts",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters correct email rmgtestdemo1@gmail.com",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user click on next button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "the user enters correct password Rmg@12345",
  "matchedColumns": [
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user click on next button to proceed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user has successfully logged in to the application",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "application should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginStepDefinition.user_already_on_login_page()"
});
formatter.result({
  "duration": 45718869327,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created\nfrom chrome not reachable\n  (Session info: chrome\u003d72.0.3626.121)\n  (Driver info: chromedriver\u003d2.46.628402 (536cd7adbad73a3783fdc2cab92ab2ba7ec361e1),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 34.04 seconds\nBuild info: version: \u00273.4.0\u0027, revision: \u0027unknown\u0027, time: \u0027unknown\u0027\nSystem info: host: \u0027LAPTOP-LOD762D0\u0027, ip: \u0027192.168.1.35\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_171\u0027\nDriver info: driver.version: ChromeDriver\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:215)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:167)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$new$0(JsonWireProtocolResponse.java:53)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$getResponseFunction$2(JsonWireProtocolResponse.java:91)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$22(ProtocolHandshake.java:365)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(Unknown Source)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyInto(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.evaluate(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.findFirst(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:368)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:159)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:142)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:637)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:250)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:236)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:137)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:184)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:148)\r\n\tat stepDefinitions.LoginStepDefinition.user_already_on_login_page(LoginStepDefinition.java:30)\r\n\tat ✽.Given User is already on the login page(login.feature:4)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "LoginStepDefinition.title_of_the_login_page_is_Google_Accounts()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "rmgtestdemo1@gmail.com",
      "offset": 26
    }
  ],
  "location": "LoginStepDefinition.user_enters_correct_username(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefinition.user_click_on_next_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Rmg@12345",
      "offset": 33
    }
  ],
  "location": "LoginStepDefinition.the_user_enters_correct_password(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefinition.user_click_on_next_button_to_proceed()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefinition.user_has_successfully_logged_into_the_application()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefinition.application_should_be_closed()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 16,
  "name": "User should be able to login with examples",
  "description": "",
  "id": "google-login;user-should-be-able-to-login-with-examples;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 2,
      "name": "@googlelogin"
    }
  ]
});
formatter.step({
  "line": 4,
  "name": "User is already on the login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "title of the login page is Google Accounts",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters correct email rmgtestdemo2@gmail.com",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user click on next button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "the user enters correct password Rmg@12345",
  "matchedColumns": [
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user click on next button to proceed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user has successfully logged in to the application",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "application should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginStepDefinition.user_already_on_login_page()"
});
formatter.result({
  "duration": 24378496943,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.title_of_the_login_page_is_Google_Accounts()"
});
formatter.result({
  "duration": 75771675,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "rmgtestdemo2@gmail.com",
      "offset": 26
    }
  ],
  "location": "LoginStepDefinition.user_enters_correct_username(String)"
});
formatter.result({
  "duration": 5220442175,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.user_click_on_next_button()"
});
formatter.result({
  "duration": 151966843,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Rmg@12345",
      "offset": 33
    }
  ],
  "location": "LoginStepDefinition.the_user_enters_correct_password(String)"
});
formatter.result({
  "duration": 5116358557,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.user_click_on_next_button_to_proceed()"
});
formatter.result({
  "duration": 5132529908,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.user_has_successfully_logged_into_the_application()"
});
formatter.result({
  "duration": 5008063990,
  "error_message": "java.lang.AssertionError: expected [Sign in – Google accounts] but found [Google Account]\r\n\tat org.testng.Assert.fail(Assert.java:94)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:494)\r\n\tat org.testng.Assert.assertEquals(Assert.java:123)\r\n\tat org.testng.Assert.assertEquals(Assert.java:176)\r\n\tat org.testng.Assert.assertEquals(Assert.java:186)\r\n\tat stepDefinitions.LoginStepDefinition.user_has_successfully_logged_into_the_application(LoginStepDefinition.java:83)\r\n\tat ✽.And user has successfully logged in to the application(login.feature:10)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "LoginStepDefinition.application_should_be_closed()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 17,
  "name": "User should be able to login with examples",
  "description": "",
  "id": "google-login;user-should-be-able-to-login-with-examples;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 2,
      "name": "@googlelogin"
    }
  ]
});
formatter.step({
  "line": 4,
  "name": "User is already on the login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "title of the login page is Google Accounts",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user enters correct email rmgtestdemo3@gmail.com",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user click on next button",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "the user enters correct password Rmg@12345",
  "matchedColumns": [
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user click on next button to proceed",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user has successfully logged in to the application",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "application should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginStepDefinition.user_already_on_login_page()"
});
